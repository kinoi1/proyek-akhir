# WAGW
## Api wa sederhana

* untuk keperluan notifikasi

## Cara install 
* buka terminal didalam folder wagw
* npm install
* tunggu samapi selesai terinstall library node_module
* jalankan server,ketik (node app.js)
* nanti muncul qr code
* setelah itu scan 

## endpoint 
https://localhost:3000/api
